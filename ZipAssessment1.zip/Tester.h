#pragma once
#include <iostream>
#include <string>
#include <fstream>
#include <cstddef>
#include "Declerations.h"
using namespace std;

void ConstructorTest();
void AppendPrependTest();
void UpperLowerTest();
void FindReplaceTest();
void EqualtoTest();
void CharacterAtTest();
void ReadWritreTest();
