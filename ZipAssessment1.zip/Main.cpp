#include <iostream>
#include <string>
#include <fstream>
#include <cstddef>
#include "Declerations.h"
#include "Tester.h"
using namespace std;

int main()
{
				// Application 
	//myString greeting("Hello World!");
	//myString happy("!!!");
	//greeting.WriteToConsole();
	//greeting.ToUpper().WriteToConsole();
	//greeting.ToLower().WriteToConsole();
	//greeting.Append(happy).WriteToConsole();

				// Test!
	//ConstructorTest();
	//AppendPrependTest();
	//UpperLowerTest();
	//FindReplaceTest();
	//EqualtoTest();  
	//CharacterAtTest();
	//ReadWritreTest();
	//cout << "All tests finished!" << endl;
	//return 0;

}